export enum UrlType {
  INTERNAL,
  EXTERNAL,
}