export interface Sign {
  address: string,
  signature: string
  message: string
}
